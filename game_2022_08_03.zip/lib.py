import pygame
import json
import os
from pygame.locals import SRCALPHA

pygame.font.init()
#print(pygame.font.get_fonts())
fonts = {}

for size in range(20,128,2):
    fonts[size]=pygame.font.SysFont("Courier Typeface", size)
fonts['title'] = pygame.font.SysFont("Verdana", 100)
FPS = 60
GRAVITY = 0.8
WIDTH = 1280
HEIGHT = 720
INPUTBOX = pygame.event.custom_type()
DIALOG = pygame.event.custom_type()


def blend_color(color1, color2):
    for i, value in enumerate(color1):
        color2[i] = min((value + color2[i]) // 2, 255)
    return color2


dark_blue = [44, 62, 80]
wet_blue = [52, 73, 94]
river_blue = [52, 152, 219]
dark_red = [192, 57, 43]
dark_green = [39, 174, 96]
sky_blue = [52, 152, 219]
silver = [189, 195, 199]
dark_gray = [127, 140, 141]
darker_gray = blend_color(dark_gray, [20, 20, 20])
cloud_white = [236, 240, 241]
dark_turquoise = [22, 160, 133]
turquoise = [26, 188, 156]
darker_red = blend_color(dark_red, [40, 40, 40])


animated_tile_duration = {0: [15, 60, 15, 60], 1: [10] * 7}


tileset_cache = {}
animated_tileset_cache = []



def load_data(path):
    if not os.path.exists(path):
        return False
    with open(path, "r") as f:
        data = json.load(f)
    return data


def save_data(path, data):
    with open(path, "w+") as f:
        json.dump(data, f)


def change_size(width, height):
    global WIDTH
    global HEIGHT
    if width:
        WIDTH = width
    if height:
        HEIGHT = height


def set_number_surf(surf, num):
    surf.fill((0, 0, 0))
    string = big_font.render(str(num + 1), 0, (200, 200, 200))
    rect = surf.get_rect(center=(16, 16))
    surf.blit(string, rect)
    surf.set_colorkey((0, 0, 0))


def remove_color(surf, color):
    surf.set_colorkey(color)
    surf.convert_alpha()
    return surf


def give_aspect_scale(img, bx, by):
    ix, iy = img.get_size()
    if ix > iy:
        # fit to WIDTH
        scale_factor = bx / float(ix)
        sy = scale_factor * iy
        if sy > by:
            scale_factor = by / float(iy)
            sx = scale_factor * ix
            sy = by
        else:
            sx = bx
    else:
        # fit to HEIGHT
        scale_factor = by / float(iy)
        sx = scale_factor * ix
        if sx > bx:
            scale_factor = bx / float(ix)
            sx = bx
            sy = scale_factor * iy
        else:
            sy = by
    return [int(sx), int(sy)]


def load_image(path, scale):
    surf = pygame.image.load(path).convert_alpha()
    surf = pygame.transform.scale(surf, scale)
    return surf

def animated_tileset_get(index,frame,flip=False):
    global animated_tileset_cache
    if flip and not animated_tileset_cache[index][frame][True]:
        animated_tileset_cache[index][frame][True]=pygame.transform.flip(
                                                animated_tileset_cache[index][frame][False],
                                                True,
                                                False
                                                )
        #print("New surface")
    return animated_tileset_cache[index][frame][flip]
def tileset_get(index,flip=False):
    global tileset_cache
    if flip and not tileset_cache[index][True]:
        tileset_cache[index][True]=pygame.transform.flip(
                                                tileset_cache[index][False],
                                                True,
                                                False
                                                )
        #print("New surface")
    #print(animated_tileset_cache)
    return tileset_cache[index][flip]
def load_tileset(path, scale):
    global tileset_cache
    img = pygame.image.load(path).convert_alpha()
    width = img.get_width() // 16
    height = img.get_height() // 16
    sheet = []
    for y in range(height):
        for x in range(width):
            sheet.append(img.subsurface([x * 16, y * 16, 16, 16]))
    for i, surf in enumerate(sheet):
        surf = pygame.transform.scale(surf, scale)
        sheet[i] = surf.copy()
        tileset_cache[i]={}
        tileset_cache[i][False]=surf.copy()
        tileset_cache[i][True]=None

    return sheet


# [ [frame1,frame2,frame3], [frame1,frame2]          ]
def load_animated_tileset(path, scale):
    global animated_tileset_cache
    img = pygame.image.load(path).convert_alpha()
    # img.convert_alpha()
    img.set_colorkey((0, 0, 0, 0))
    width = img.get_width() // 16
    height = img.get_height() // 16
    scaled_surf = pygame.surface.Surface(scale, SRCALPHA)
    # scaled_surf.fill((0,0,0,0))
    sheet = []
    for y in range(height):
        sheet.append([])
        animated_tileset_cache.append([])

        for x in range(width):
            if img.get_at((x * 16, y * 16)) == (0, 0, 0, 255):
                break
            pygame.transform.scale(
                img.subsurface([x * 16, y * 16, 16, 16]), scale, scaled_surf
            )
            sheet[y].append(scaled_surf.copy())
            animated_tileset_cache[y].append({})
            animated_tileset_cache[y][x][False]=scaled_surf.copy()
            animated_tileset_cache[y][x][True]=None

    return sheet


def render_text(text, font_size=0, color=(255, 255, 255)):

    if font_size in fonts.keys():
        font = fonts[font_size]
    else :
        font = list(fonts.values())[0]
    size = font.size(text)
    surf = pygame.surface.Surface(size).convert()
    surf.fill((255, 0, 255))
    surf.set_colorkey((255, 0, 255))
    string_render = (
        font.render(text, 0, color)
    )
    surf.blit(string_render, (0, 0))
    return surf


character_sprites = {}

def load_character_sprites():
    global character_sprites
    if not character_sprites=={}:return character_sprites
    path_to_character_animation= 'Assets/characters/'

    #print("Files and directories in a specified path:")
    for filename in os.listdir(path_to_character_animation):
        dir = os.path.join(path_to_character_animation,filename)
        if not os.path.isdir(dir):continue
        character_sprites[filename]={}
        for image_file in os.listdir(dir):
            image_path = os.path.join(dir,image_file)
            if not os.path.isfile(image_path):continue
            if not image_file.split('.')[1]=='png':continue
            #print(image_file)
            character_sprites[filename][image_file.split('.')[0]]=load_image(image_path,(640,720))
    #print(character_sprites)
    return character_sprites
