from textbox import TextBox
from lib import *
import pygame


class DialogBox(TextBox):
    def __init__(
        self,
        list,
        x,
        y,
        width,
        height,
        text="",
        font=26,
        color=[50, 50, 50],
        align="center",
        padding=5
    ):
        super().__init__(list, x, y, width, height,'',font,color,align)
        self.color = color
        self.font = font
        self.align = align
        self.text=[text]
        self.padding = padding
        self.text_rect = None

        self.set_text(text, color)
        self.clear_text()
        # self.image.set_alpha(255)

    def set_text(self, text, color=None):
        if color:
            self.color = color
        self.text = text.split('\n')
        self.draw()

    def clear_text(self):
        self.text = []
        self.draw()
    def draw(self):

        self.image.fill(self.color)

        for i,line in enumerate(self.text):
            self.text_surf = render_text(line, self.font, (200, 200, 200))
            self.text_rect = self.text_surf.get_rect()
        # self.text_surf.set_colorkey((0,0,0))

            self.text_rect.top = self.padding+(30*i)
            if self.align == "center":
                self.text_rect.centerx = self.rect.w // 2
            elif self.align == "left":
                self.text_rect.left = 0 + self.padding
            elif self.align == "right":
                self.text_rect.right = self.rect.w - self.padding
        # self.image.blit(self.text_surf,self.text_rect.move(2,0))
        # self.text_surf = render_text(self.text,self.font,(0,0,0))
        # pygame.draw.rect(self.image,(200,0,0),self.text_rect,2)

            self.image.blit(self.text_surf, self.text_rect)
            #pygame.draw.rect(self.image,(0,0,200),self.text_rect,2)
        # pygame.draw.rect(self.image,(100,100,100),(-10,0,self.rect.w +20,self.rect.h),3)
