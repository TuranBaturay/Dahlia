from textbox import TextBox
from panel import Panel
import pygame
import lib as lib


class Button(Panel):
    def __init__(
        self,
        list,
        x,
        y,
        width,
        height,
        text=None,
        func=None,
        image=None,
        color=[50, 50, 50],
    ):
        self.text_panel = None
        self.disabled = False
        self.func = func
        self.right_click_func = None
        self.feedback = 0
        self.mouse_in_flag = False
        self.color = color
        self.img = image
        super().__init__(list, x, y, width, height)
        if text:
            self.text_panel = TextBox(
                None,
                0,
                0,
                width,
                height,
                text=text,
                align="center",
                color=(255, 0, 255),
            )
            #self.text_panel.image.set_colorkey((255, 0, 255))
            self.text_panel.color = (0, 0, 0, 0)

        self.draw()
        # self.image.set_alpha(200)

    def set_img(self, img):
        self.img = img
        self.image.convert_alpha()
        self.color = (0, 0, 0, 0)
        # self.image.set_colorkey((255,0,255))
        # print(img)
        self.draw()

    def set_text(self, text):
        if not self.text_panel:
            return
        self.text_panel.set_text(text)
        self.draw()

    def set_func(self, func=None):
        if func:
            self.func = func

    def set_right_click_func(self, func=None):
        if func:
            self.right_click_func = func

    def set_color(self, color):
        self.color = color
        self.text_panel.set_text(self.text_panel.text, color)
        self.draw()

    def right_click(self):
        if self.right_click_func:
            self.right_click_func()

    def click(self):
        # print("---------------------CLICK")
        if self.func:
            self.func()
        self.feedback = 10
        self.draw()

    def mouse_enter(self):
        self.draw()

    def mouse_leave(self):
        self.draw()

    def enable(self):
        self.disabled = False
        self.feedback = 0
        self.draw()

    def disable(self):
        self.disabled = True
        self.draw()

    def update(self, mouse_pos, mouse_button, *args):
        super().update(mouse_pos, mouse_button)
        if self.mouse_in:
            if mouse_button[1] and not self.disabled:
                self.click()
            if mouse_button[3] and not self.disabled:
                self.right_click()
        if self.feedback > 0:
            self.feedback -= 1
            self.draw()

    def draw(self):

        if self.text_panel:
            self.text_panel.draw()
            # self.text_panel.image.set_alpha(255)

        if self.disabled:
            self.image.fill(lib.blend_color(self.color, [100, 100, 100]))
            # self.image.fill(lib.dark_red)
        else:
            # pass
            self.image.fill(self.color)
        if self.img:
            self.image.blit(self.img, (0, 0))

        if self.feedback > 0 or (self.mouse_in and not self.disabled):
            if not self.img:
                self.image.fill(lib.blend_color(self.color, [140, 140, 140]))

            # pygame.draw.rect(self.image,(100,0,100),(0,0,*self.rect.size),3)

            if self.text_panel:
                self.image.blit(self.text_panel.image, (0, 0))
            if self.feedback > 0:
                pygame.draw.rect(
                    self.image,
                    (200, 200, 200),
                    (0, 0, self.rect.w, self.rect.h),
                    self.feedback + 3,
                )
        else:
            if self.text_panel:
                self.image.blit(self.text_panel.image, (0, 0))
