from panel import Panel
from lib import *
import pygame


class TextBox(Panel):
    def __init__(
        self,
        list,
        x,
        y,
        width,
        height,
        text="",
        font=26,
        color=[50, 50, 50],
        align="center"
    ):
        super().__init__(list, x, y, width, height,color)
        self.color = color
        self.font = font
        self.align = align
        self.text = text
        self.padding = 5
        self.text_rect = None
        self.set_text(text, color)
        # self.image.set_alpha(255)

    def set_text(self, text, color=None):
        if color:
            self.color = color
        self.text = text
        self.draw()

    def draw(self):

        self.image.fill(self.color)
        self.text_surf = render_text(self.text, self.font, (200, 200, 200))
        self.text_rect = self.text_surf.get_rect()
        # self.text_surf.set_colorkey((0,0,0))

        self.text_rect.centery = self.rect.h // 2
        if self.align == "center":
            self.text_rect.centerx = self.rect.w // 2
        elif self.align == "left":
            self.text_rect.left = 0 + self.padding
        elif self.align == "right":
            self.text_rect.right = self.rect.w - self.padding
        # self.image.blit(self.text_surf,self.text_rect.move(2,0))
        # self.text_surf = render_text(self.text,self.font,(0,0,0))
        #pygame.draw.rect(self.image,(200,0,0),self.text_rect,2)

        self.image.blit(self.text_surf, self.text_rect)
        # pygame.draw.rect(self.image,(0,0,200),self.rect,1)
        # pygame.draw.rect(self.image,(100,100,100),(-10,0,self.rect.w +20,self.rect.h),3)
