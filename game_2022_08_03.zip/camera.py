from pygame.math import Vector2
from lib import *


class Camera:
    def __init__(self, game):
        self.game = game
        self.true_pos = Vector2(0, 0)
        self.int_pos = Vector2(0, 0)
        self.target = Vector2(0, 0)
        self.zoom = 1

    def set_target(self, target: Vector2):
        self.target = target

    def set_zoom(self, zoom):
        self.zoom = zoom

    def update(self, dt):
        if self.game.mode == "game":
            self.true_pos.x += (
                self.zoom * self.target.x - self.zoom * self.true_pos.x - WIDTH / 2
            ) / 10
            self.true_pos.y += (
                self.zoom * self.target.y - self.zoom * self.true_pos.y - HEIGHT / 2
            ) / 10

        self.int_pos = Vector2(int(self.true_pos.x), int(self.true_pos.y))
