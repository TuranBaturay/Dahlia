import pygame
from pygame import Vector2
from pygame.locals import *
from math import floor
import lib as lib


class Player(pygame.sprite.Sprite):
    def __init__(self, _display, game):
        pygame.sprite.Sprite.__init__(self)
        self.vel = Vector2(0, 0)
        self.movement_keys = [K_UP, K_RIGHT, K_LEFT, K_DOWN]
        self.game = game

        self.speed = 2.5
        self.camera = game.camera
        self.jump_force = 12
        self.state = "idle"
        self.state_lock = False
        self.on_ground = False
        self.face_right = True
        self.land = False
        self.animation_dict = {}
        self.sfx = {
            "jump": pygame.mixer.Sound("Audio/sfx/jump.wav"),
            "run": pygame.mixer.Sound("Audio/sfx/run.wav"),
            "hide": pygame.mixer.Sound("Audio/sfx/hide.wav"),
        }
        self.load_animations(
            "Assets/Animation/Dahlia/run.png", [5, 5, 5, 5]
        )  # run animation
        self.load_animations(
            "Assets/Animation/Dahlia/idle.png", [10, 10, 10, 10]
        )  # idle animation
        self.load_animations(
            "Assets/Animation/Dahlia/hide.png", [3, 3, 10, 4, 5, 3, 1000]
        )
        self.load_animations("Assets/Animation/Dahlia/fall.png", [5, 5])
        self.load_animations("Assets/Animation/Dahlia/jump.png", [3, 10000])

        self.display = _display
        self.animation_counter = 0
        self.image = self.animation_dict["idle"][0]
        self.rect = pygame.rect.Rect(0, 0, 32, 52)
        self.spell_source = Vector2(
            (self.rect.right + 40 * self.face_right)
            + (self.rect.left - 40 * self.face_right * -1),
            self.rect.centery,
        )

        self.player_tile = [0, 0]
        self.draw_rect = pygame.rect.Rect(0, 0, 64, 64)
        self.hitbox = pygame.rect.Rect(
            0, 0, self.rect.w, self.rect.h
        )  # only for debuuging in self.draw_hitbox

    def go_to(self, new_pos, anchor="center"):
        pos = Vector2(new_pos)
        if anchor == "center":
            pos -= Vector2(self.rect.w // 2, self.rect.h // 2)
        elif anchor == "nw":
            pass
        elif anchor == "n":
            pos -= Vector2(self.rect.w // 2, 0)
        elif anchor == "s":
            pos -= Vector2(self.rect.w // 2, self.rect.h)
        self.rect.topleft = pos
        self.vel = Vector2(0, 0)

    def set_state(self, state, reset=True):
        if self.state_lock:
            return
        self.state = state
        if reset:
            self.animation_counter = 0

    def lock_state(self):
        self.state_lock = True

    def unlock_state(self):
        self.state_lock = False

    def load_animations(self, path, durations):
        filename = path.split("/")[-1].split(".png")[0]
        self.animation_dict[filename] = []
        spritesheet = pygame.image.load(path).convert_alpha()
        sheet = [
            spritesheet.subsurface([i * 16, 0, 16, 16]) for i in range(len(durations))
        ]
        for i in range(len(durations)):
            img = sheet[i]
            # img1 = remove_color(img1,(255,0,255))
            img1 = pygame.transform.scale(img, (64, 64))

            for j in range(durations[i]):
                self.animation_dict[filename].append(img1.copy())

    def handle_collision_x(self):
        flag = False

        for value in self.game.level.layers:
            layer = value[1]
            for tile in layer.get_neighbor_sprites(*self.player_tile):
                ####print(self.rect)
                if self.rect.colliderect(tile.rect):
                    if self.vel.x > 0:
                        self.rect.right = tile.rect.left
                    elif self.vel.x < 0:
                        self.rect.left = tile.rect.right
                    self.vel.x = 0
                    flag = True
                    break
            if flag:
                break

    def handle_collision_y(self):
        flag = False

        for value in self.game.level.layers:
            layer = value[1]
            for tile in layer.get_neighbor_sprites(*self.player_tile):
                if self.rect.colliderect(tile.rect):
                    if self.vel.y > 0:
                        self.rect.bottom = tile.rect.top
                        if not self.on_ground:
                            self.on_ground = True
                            self.land = True
                            self.sfx["run"].play()
                    elif self.vel.y < 0:
                        self.rect.top = tile.rect.bottom
                    self.vel.y = 0
                    flag = True
                    break
            if flag:
                break

    def input(self, dt):
        keys = pygame.key.get_pressed()
        if all(keys[v] == False for v in [K_LEFT, K_RIGHT]) and -0.9 < self.vel.y < 0.9:
            self.vel.x = 0
            if self.state != "idle" and self.state != "hide":
                self.set_state("idle")
        if keys[K_DOWN] and self.on_ground:
            if self.state != "hide":
                # print(self.state)
                self.set_state("hide")

                self.sfx["hide"].play()
            self.vel.x = 0
            return
        elif self.state == "hide":
            self.set_state("idle")
        if keys[K_RIGHT]:
            self.vel.x += self.speed
            self.face_right = True
        if keys[K_LEFT]:
            self.vel.x -= self.speed
            self.face_right = False
        if keys[K_UP]:
            if self.on_ground:
                # self.on_ground = False
                self.set_state("jump")
                self.lock_state()
                #print("JUMP")

    # def get_tile(self,x,y):
    #     return self.game.level.get(int(x),int(y))
    def update(self, dt):
        old_dt = dt
        dt *= lib.FPS
        self.animation_counter = int(self.animation_counter + (1.5 * dt))
        if self.land:
            self.land = False

        self.vel.x = round(self.vel.x, 1)
        self.vel.y = round(self.vel.y, 1)
        # pygame.draw.circle(self.display,(200,200,200),self.spell_source,5)
        # self.game.debugger.set("Vel",self.vel)
        self.player_tile[0] = floor(self.rect.x // 64)
        self.player_tile[1] = floor(self.rect.y // 64)

        # handle input
        self.input(dt)
        # handle state


        self.vel.x *= 0.7
        self.vel.y += lib.GRAVITY
        self.vel.y = min(20, self.vel.y)


        #print(dt)

        if self.on_ground and self.state != "hide":
            if self.vel.x != 0:
                if self.state != "run":
                    self.set_state("run")
                elif self.animation_counter == 5 and not self.land:
                    self.sfx["run"].play()

            else:
                if self.state != "idle":
                    self.set_state("idle")

        #print(self.animation_counter)
        if self.state == "jump" and self.animation_counter >=4 and self.state_lock:  # 3 is jump frame
            self.unlock_state()
            self.vel.y -= self.jump_force
            self.sfx["jump"].play()
            #print(self.animation_counter,"Jump")
            self.on_ground = False

        # handle collision

        self.rect.y += self.vel.y *dt
        self.handle_collision_y()
        self.rect.x += self.vel.x * dt
        self.handle_collision_x()

        if (self.vel.y > lib.GRAVITY) and self.state != "fall":
            #print("--->", self.vel.y)
            self.set_state("fall")
            self.on_ground = False
        # handle animation

        # print(self.state,self.vel.y)
        if self.animation_counter >= len(self.animation_dict[self.state]):
            self.animation_counter = 0

        self.image = self.animation_dict[self.state][int(self.animation_counter)]
        if not self.face_right:
            self.image = pygame.transform.flip(self.image, True, False)
        self.draw()

    def draw(self):
        self.draw_rect.bottom = self.rect.bottom
        self.draw_rect.centerx = self.rect.centerx
        self.draw_rect.x -= self.camera.int_pos.x
        self.draw_rect.y -= self.camera.int_pos.y

        self.display.blit(self.image, self.draw_rect)
        if self.game.show_hitbox:
            self.draw_hitbox()

    def draw_hitbox(self):
        self.hitbox.bottom = self.rect.bottom - self.camera.int_pos.y
        self.hitbox.centerx = self.rect.centerx - self.camera.int_pos.x
        pygame.draw.rect(self.display, (200, 100, 120), self.draw_rect, 3)
        pygame.draw.rect(self.display, (100, 200, 120), self.hitbox, 2)
