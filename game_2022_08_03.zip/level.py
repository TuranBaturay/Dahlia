from layer import Layer
from lib import *
import pygame.time
from pygame.locals import SRCALPHA
from pygame.math import Vector2


class Level:
    def __init__(self, display, game):
        self.size = 4
        self.chunk_size = 8
        self.display = display
        self.total = 0
        self.game = game
        self.tileset = self.game.tileset
        self.animated_tileset = self.game.animated_tileset
        self.camera = game.camera
        self.layers = []
        self.layer_order = []
        self.layer_count = 0
        self.surf = pygame.surface.Surface((WIDTH, HEIGHT))  # .convert()
        self.surf.fill((0, 0, 0, 0))
        self.hitbox_surf = self.surf.copy()
        self.last_camera_value = Vector2(0, 0)
        self.num = [
            (0, 0),
            (1, 0),
            (-1, 0),
            (0, 1),
            (0, -1),
            (1, 1),
            (-1, -1),
            (-1, 1),
            (1, -1),
        ]

        # Pre_rendered border surfaces
        self.chunk_border = pygame.surface.Surface(
            (self.chunk_size * 64, self.chunk_size * 64)
        )
        self.tile_border = pygame.surface.Surface((64, 64))
        self.tile_border.set_colorkey((0, 0, 0))
        self.chunk_border.set_colorkey((0, 0, 0))

        pygame.draw.rect(self.tile_border, (200, 100, 200), (0, 0, 64, 64), 2)
        pygame.draw.rect(
            self.chunk_border, (100, 200, 100), (0, 0, *self.chunk_border.get_size()), 2
        )

        for _ in range(3):
            self.add_layer()
        # 8 is chunk size
        for x in range(0, self.size * self.chunk_size):
            self.set(
                x,
                16,
                self.layers[0][0],
                {"index": 0, "collision": True, "flip": False},
                update_chunk=True,
            )

    def save_to_file(self, filename="level"):
        path = "levels/" + filename + ".json"
        data = {}
        data["size"] = self.size
        data["chunk_size"] = self.chunk_size
        data["layers"] = []
        for layer in self.layers:
            data["layers"].append([layer[0], layer[1].format()])
        save_data(path, data)

    def level_exists(self, filename):
        path = "levels/" + filename + ".json"
        data = load_data(path)
        return True if data else False

    def load_from_file(self, filename):
        path = "levels/" + filename + ".json"
        data = load_data(path)
        if not data:
            return False
        self.total = 0
        self.layer_count = 0
        self.chunk_size = data["chunk_size"]
        self.size = data["size"]
        self.layers = []
        for i, value in enumerate(data["layers"]):
            id = value[0]
            layer_data = value[1]
            self.add_layer(id)
            if layer_data:
                self.layers[i][1].load(layer_data)

        # self.layer_order = data['layer_order']

        return True

    def get_layer_list(self):
        return [value[0] for value in self.layers]

    def get_layer_index(self, layer):
        for i in range(len(self.layers)):
            if self.layers[i][0] == layer:
                return i
        return -1

    def get_layer_name(self, index):
        if index < 0 or index > len(self.layers):
            return None
        return self.layers[index][0]

    def get_layer(self, layer):
        if isinstance(layer, int):
            if layer >= len(self.layers):
                return None
            return self.layers[layer]
        for i in self.layers:
            if i[0] == layer:
                return i[1]
        return None

    def swap_layers(self, index1, index2):
        if (
            index1 < 0
            or index2 < 0
            or index2 >= len(self.layers)
            or index1 >= len(self.layers)
        ):
            return
        self.layers[index1], self.layers[index2] = (
            self.layers[index2],
            self.layers[index1],
        )
        return True

    def set(self, x, y, layer_name, tile_data, update_chunk=True):
        layer = self.get_layer(layer_name)
        if not layer:
            return False
        res = layer.set(x, y, tile_data, update_chunk)
        # if res : self.blit_layers(True)
        return res

    def remove(self, x, y, layer_name):
        layer = self.get_layer(layer_name)
        if not layer:
            return False
        res = layer.remove(x, y)
        # if res : self.blit_layers(True)
        return res

    def get(self, x, y, layer_name):
        layer = self.get_layer(layer_name)
        if not layer:
            return False
        return layer.get_tile(x, y)

    def add_layer(self, name=None):
        if name == None:
            name = "Layer " + str(self.layer_count + 1)
        self.layers.append(
            [
                name,
                Layer(
                    self.camera,
                    self.tileset,
                    self.animated_tileset,
                    self.size,
                    self.chunk_size,
                ),
            ]
        )
        self.layer_count += 1

    def rename_layer(self, oldlayer, newlayer):
        index = self.get_layer_index(oldlayer)
        if index == -1:
            return False
        self.layers[index][0] = newlayer
        return True

    def remove_layer(self, layer):
        index = self.get_layer_index(layer)
        if index == -1:
            return False
        self.layers.pop(index)
        return True

    def set_layer_visible(self, layer_name, visible=True):
        layer = self.get_layer(layer_name)
        if not layer:
            return False
        # print("set",layer,"visible : ",visible)
        layer.show = visible

    def blit_layer(self, layer, hitbox=False):
        # self.surf.fill((0,0,0))
        if layer not in self.get_layer_list():
            return 0
        tmp = self.get_layer(layer)
        counter = 0
        counter += tmp.blit_chunks()
        # self.surf.blit(tmp.surf,(0,0))
        self.display.blit(tmp.surf, (0, 0))
        return counter

    def blit_layers(self, hitbox=False):
        counter = 0
        blit_list = []

        for layer in self.layers:
            if layer[1].total == 0 or not layer[1].show:
                continue

            counter += layer[1].blit_chunks(self.display)
            if hitbox:
                blit_rect = self.chunk_border.get_rect()
                chunk_list = layer[1].get_neighbor_chunks_of_tile(
                    (WIDTH // 2 + self.camera.int_pos.x) // 64,
                    (HEIGHT // 2 + self.camera.int_pos.y) // 64,
                )
                for chunk_info in chunk_list:
                    blit_rect.topleft = [
                        chunk_info[i] * self.chunk_size * 64 - self.camera.int_pos[i]
                        for i in [0, 1]
                    ]
                    if not blit_rect in [i[1] for i in blit_list]:
                        blit_list.append([self.chunk_border, blit_rect.copy()])

        if hitbox:
            self.display.blits(blit_list)

        return counter

    def load_all(self, tileset=None, animated_tileset=None):
        print("Loading level")
        start = pygame.time.get_ticks()
        if tileset:
            self.tileset = tileset
        if animated_tileset:
            self.animated_tileset = animated_tileset
        for i in self.layers:
            print("Level reload layer", i[0])
            i[1].reload(self.tileset, self.animated_tileset)
        # self.blit_layers()
        time = (pygame.time.get_ticks() - start) / 1000
        print(f"level loaded in {time}s")

    def update(self, dt):
        for layer in self.layers:
            layer[1].update(dt)
