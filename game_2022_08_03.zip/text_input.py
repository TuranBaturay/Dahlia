import pygame
from textbox import TextBox
from button import Button

from pygame.locals import *
import lib as lib

# Only 1 per game
class Singleton(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
            # print("New")
        return cls._instances[cls]


class TextInput(TextBox, metaclass=Singleton):
    def __init__(
        self, list, width, height, max_len=20, blink_speed=50, color=lib.dark_blue
    ):
        self.animation_counter = 0
        self.cursor_rect = pygame.rect.Rect(0, 0, 0, 0)

        self.validate_button = Button(
            None, 0, 0, height, height, "OK", func=self.validate, color=color
        )
        self.cancel_button = Button(
            None, 0, 0, height, height, "X", func=self.cancel, color=color
        )

        self.blink_speed = blink_speed
        self.label = TextBox(
            None, 0, 0, width, height, "Label", align="left", color=lib.wet_blue
        )

        super().__init__(
            list, 0, 0, width - height, height * 2, align="left", color=color
        )
        # self.image.set_alpha(255)

        self.rect.center = (lib.WIDTH // 2, lib.HEIGHT // 2)
        self.rect.y += height
        self.rect.h = self.rect.h // 2

        self.cursor_rect.update(5, 0, 5, self.rect.h // 1.6)
        self.cursor_rect.centery = self.rect.h // 2 + self.rect.h

        self.validate_button.rect.topleft = (
            self.rect.right - height,
            self.rect.y + height,
        )
        self.cancel_button.rect.topright = self.validate_button.rect.topleft

        self.asking_input = False
        self.on_event = pygame.event.Event(lib.INPUTBOX, key="ON")
        self.off_event = pygame.event.Event(lib.INPUTBOX, key="OFF", text=self.text)
        self.max_len = max_len
        self.func = None
        # print(self.rect,self.validate_button.rect)

    def ask_input(self, func=None, label=None, max_len=None):
        if func:
            self.func = func
        if max_len != None:
            self.max_len = max_len
        if label:
            self.label.set_text(label)
        self.show()
        pygame.event.post(self.on_event)
        self.asking_input = True

    def cancel(self):
        # print("Cancel")
        self.hide()
        self.clear_text()
        self.off_event = pygame.event.Event(lib.INPUTBOX, key="OFF", text=None)
        pygame.event.post(self.off_event)
        if self.func:
            self.func(None)
        self.asking_input = False

    def clear_text(self):
        self.text = ""
        super().set_text("")
        self.cursor_rect.centerx = self.text_rect.right + 5

    def validate(self):
        # print("Validate")
        self.hide()
        self.off_event = pygame.event.Event(lib.INPUTBOX, key="OFF", text=self.text)
        pygame.event.post(self.off_event)
        self.asking_input = False
        if self.func:
            self.func(self.text)
        self.clear_text()

    def key_down(self, key, caps):
        if key == K_ESCAPE:
            self.cancel()
            return
        key_str = pygame.key.name(key)
        if caps:
            key_str = key_str.upper()
        if not len(key_str) == 1:
            if key == K_BACKSPACE and len(self.text) > 0:
                self.set_text(self.text[:-1])
            elif key == K_SPACE and len(self.text) < self.max_len:
                self.set_text(self.text + " ")
            elif key == K_RETURN:
                self.validate()
            elif key == K_DELETE:
                self.clear_text()

        elif key_str.isalnum() and len(self.text) < self.max_len:
            self.set_text(self.text + key_str)
        self.cursor_rect.centerx = self.text_rect.right + 5

    def get_text(self):
        return self.text

    def update(self, mouse_pos, mouse_button, mouse_pressed=None):
        super().update(mouse_pos, mouse_button, mouse_pressed)
        self.validate_button.update(mouse_pos, mouse_button)
        self.cancel_button.update(mouse_pos, mouse_button)

        if self.asking_input:
            self.draw()

    def draw(self):
        self.image.fill(self.color)
        self.text_surf = lib.render_text(self.text, self.font, (200, 200, 200))
        self.text_rect = self.text_surf.get_rect()

        self.text_rect.centery = self.cursor_rect.centery
        if self.align == "center":
            self.text_rect.centerx = self.rect.w // 2
        elif self.align == "left":
            self.text_rect.left = 0 + self.padding
        elif self.align == "right":
            self.text_rect.right = self.rect.w - self.padding

        self.image.blit(self.text_surf, self.text_rect)

        self.validate_button.draw()
        # pygame.draw.rect(self.image,(200,20,200),self.text_rect,2)
        if self.animation_counter < self.blink_speed:
            pygame.draw.rect(self.image, (200, 200, 200), self.cursor_rect)
            # print("Draw")
        self.animation_counter += 1
        if self.animation_counter > self.blink_speed * 2:
            self.animation_counter = 0
        rect = self.validate_button.rect.move(
            -self.rect.right + self.rect.w, -self.rect.y
        )
        # print("draw ->",self.validate_button.rect)
        self.image.blit(self.validate_button.image, rect)
        rect = self.cancel_button.rect.move(
            -self.rect.right + self.rect.w, -self.rect.y
        )

        self.image.blit(self.cancel_button.image, rect)

        self.image.blit(self.label.image, self.label.rect)
        pygame.draw.rect(self.image, (200, 200, 200), self.rect, 2)
