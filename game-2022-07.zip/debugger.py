import pygame
from lib import *
from pygame.locals import SRCALPHA
class Debugger:
    def __init__(self,_display) -> None:
        self.dict = {}
        self.persistent = {}
        self.keys = []
        self.display = _display
        self.show = True
        self.surf = pygame.surface.Surface((WIDTH,HEIGHT),SRCALPHA)
        self.surf.fill((0,0,0,0))
        self.display_rect = self.surf.get_rect()
        self.max_y = 0
        self.min_x= 0
    def hide(self):
        self.show = False
    def show(self):
        self.show = True
    def toggle_visibility(self,bool=None):
        if bool:
            self.show = bool
            return
        self.show=not self.show
    def set(self,key,value,persistent=False):
        if not key in self.keys:self.keys.append(key)
        if key in self.dict.keys() and value == self.dict[key]:
            self.persistent[key]=persistent
            #self.draw()
            return

        self.dict[key]=value
        self.persistent[key]=persistent
        ypos = 20+self.keys.index(key)*20
        self.surf.fill((0,0,0,0),(0,ypos,WIDTH,20))
        #self.surf.set_colorkey((255,0,255))
        string = key+":"+str(value)
        string_render = font.render(string, 0 , (255,255,255))
        rect = string_render.get_rect()
        self.min_x = min(self.min_x,rect.w-20)
        self.surf.fill((0,0,0,0),rect)
        self.surf.blit(string_render,(self.display_rect.w-rect.w-20,ypos))
        self.max_y+=20

    def update(self):
        if self.show:
            self.display.blit(self.surf,(0,0),(self.min_x,0,WIDTH-self.min_x,20+self.max_y))
            return
        self.draw()
        return
        counter=20
        for key,value in self.persistent.items():
            if value:
                ypos = 20+20*self.keys.index(key)
                self.display.blit(self.surf,(0,counter),(0,ypos,WIDTH,20))
            counter+=20
    def draw(self):
        #self.surf.fill((0,0,0,0))

        #self.surf.fill((255,0,255))
        counter = 20
        for key in self.keys:
            if not self.show and not self.persistent[key]:
                counter+=20
                continue
            value = self.dict[key]
            string = key+":"+str(value)
            string_render = font.render(string, 0 , (255,255,255))
            self.display.blit(string_render,(self.display_rect.w-string_render.get_rect().w-20,counter))
            counter += 20
        #self.surf.set_colorkey((255,0,255))
