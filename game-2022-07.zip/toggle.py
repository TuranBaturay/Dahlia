from button import Button
from panel import Panel
from textbox import TextBox
import pygame
import lib as lib
class Toggle(Button):
    def __init__(self,list,x,y,width,height,text = None,func=None,color=None):
        self.text_panel = None
        self.box = pygame.rect.Rect(0,0,height//2,height//2)
        self.box.center = (height//2,height//2)
        self.value = False
        Button.__init__(self,list,x,y,width,height,func=func,color=color)
        if text:
            self.text_panel = TextBox(None,0,0,width-height,height,text=text,align='left',color=color)
        self.draw()
    def set_text(self,text):
        if not self.text_panel:return
        self.text_panel.set_text(text)
        self.draw()
    def get(self):
        return self.value
    def click(self):
        self.toggle()
    def toggle(self,value=None,callback = True):
        self.value = not self.value if value==None else value
        if self.func and callback:
            self.func(self.value)
        self.draw()
    def draw(self):
        self.image.fill(self.color)
        if self.value:
            pygame.draw.rect(self.image,(lib.dark_green),self.box)
        else:
            pygame.draw.rect(self.image,lib.darker_red,self.box)
        pygame.draw.rect(self.image,(200,200,200),self.box,2)

        if self.text_panel :
            self.image.blit(self.text_panel.image,(self.box.w*2,0))
        #pygame.draw.rect(self.image,(100,0,100), self.rect,3)
