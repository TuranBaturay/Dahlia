import pygame
from chunk import Chunk
from lib import WIDTH, HEIGHT
from pygame.locals import SRCALPHA
class Layer:
    def __init__(self,camera,tileset,animated_tileset,size,chunk_size):
        self.total = 0
        self.size = max(size,4) # 4 is min size
        self.chunk_size = chunk_size
        self.tileset = tileset
        self.animated_tileset=animated_tileset
        self.camera = camera
        self.surf = pygame.surface.Surface((WIDTH,HEIGHT)).convert_alpha()
        self.surf.fill((0,0,0,0))
        #self.surf.set_alpha(None)
        self.chunks = [[None for _ in range(self.size)] for _ in range(self.size)]
        self.show = True
        self.blit_rect = pygame.rect.Rect(0,0,0,0)
        #self.surf.set_alpha(255)
    def load(self,data):
        if data == None:return
        self.chunks = []
        data_y = len(data)
        self.size = max(data_y,4)
        self.total = 0
        for y in range(self.size):
            self.chunks.append([])
            for x in range(self.size):
                if y>=data_y or x>=len(data[y]):
                    self.chunks[y].append(None)
                else:
                    if isinstance(data[y][x],Chunk):
                        self.chunks[y].append(data[y][x])
                        continue
                    if data[y][x]!=None:
                        self.chunks[y].append(Chunk(self.tileset,self.animated_tileset,self.chunk_size,(x,y)))
                        self.chunks[y][x].load(data[y][x],(x,y),self.chunk_size)
                        #print(x,y,self.chunks[y][x].total,self.total)
                        self.total+=self.chunks[y][x].total
                        continue
                    self.chunks[y].append(None)

    def format(self):
        #print(self.total)
        if self.total == 0:
            return None
        data = []
        for y,row in enumerate(self.chunks):
            data.append([])
            for x,chunk in enumerate(row):
                if chunk==None or chunk.total ==0:
                    data[y].append(None)
                else:
                    data[y].append(chunk.format())
        return data
    def double_size(self):
        for y in range(self.size):
            self.chunks.append([])
        self.size *= 2
        print(len(self.chunks))
        self.load(self.chunks)
    def get_total(self):
        return self.total

    def tile_out_of_bounds(self,x,y):
        x = x//self.chunk_size
        y = y//self.chunk_size
        return (x < 0 or y <0 or x>=self.size or y >= self.size)
    def get_collision_group(self):
        group = []
        for row in self.chunks:
            for chunk in row :
                if not chunk:continue
                group.extend(chunk.collision_group.sprites())
        return group
    def get_chunk_of_tile(self,x,y):
        if self.tile_out_of_bounds(x,y):
            return 0
        x = x//self.chunk_size
        y = y//self.chunk_size
        return self.chunks[y][x]
    def get_chunk(self,x,y):
        if x < 0 or y < 0 or x >=self.size or y >=self.size:
            return 0
        return self.chunks[y][x]
    def get_tile_relative_pos(self,x,y):
        return [x%self.chunk_size,y%self.chunk_size]
    def get_neighbor_chunks_of_tile(self,x,y):
        x= int(x//self.chunk_size)
        y =int(y//self.chunk_size)
        #print(x,y)
        num = [(0,0),(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1),(-1,1),(1,-1),(-2,0),(-2,1),(-2,-1),(2,-1),(2,0),(2,1)]
        group =[]
        for i in num:
            chunk = self.get_chunk(x+i[0],y+i[1])
            if not chunk:continue
            group.append([x+i[0],y+i[1],chunk])
        return group
    def get_neighbor_sprites(self,x,y):
        num = [(0,0),(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1),(-1,1),(1,-1)]
        group =[]
        for i in num:
            chunk = self.get_chunk_of_tile(x+i[0],y+i[1])
            if not chunk:continue
            group.extend(chunk.collision_group.sprites())
        return group
    def get_tile(self,x,y):
        chunk = self.get_chunk_of_tile(x,y)
        if chunk == 0 : return 0
        if chunk == None : return None
        return chunk.get(*self.get_tile_relative_pos(x,y))
    def remove(self,x,y):
        chunk = self.get_chunk_of_tile(x,y)
        if not chunk : return
        tile_pos = self.get_tile_relative_pos(x,y)
        res = chunk.remove(*tile_pos)
        if res :
            self.blit_chunk(*chunk.pos)
            self.total -=1
        return res
    def add_chunk(self,x,y):
        if x<0 or y<0 : return None
        new_chunk = Chunk(self.tileset,self.animated_tileset,self.chunk_size,(x,y))
        self.chunks[y][x]=new_chunk
        return new_chunk

    def set(self,x,y,tile_data,update_chunk=True)-> bool:
        if x < 0 or y < 0 : return False
        chunk = self.get_chunk_of_tile(x,y)
        if chunk == 0:
            while chunk == 0:
                self.double_size()
                chunk = self.get_chunk_of_tile(x,y)
        if not chunk:
            chunk_pos = [x//self.chunk_size,y//self.chunk_size]
            chunk = self.add_chunk(*chunk_pos)
        self.total -= chunk.total
        tile_pos = self.get_tile_relative_pos(x,y)
        res = chunk.set(*tile_pos,tile_data,update_chunk)
        if update_chunk :
            self.blit_chunk(*chunk.pos)

        self.total+=chunk.total
        return res

    def blit_chunk(self,x,y,blit_tiles=False,replace_bg=True,tileset=None,animated_tileset=None):
        chunk = self.get_chunk(x,y)
        if not chunk: return False
        #print("blit chunk : ",chunk.pos)
        factor = self.chunk_size*64
        self.blit_rect.update(chunk.pos[0]*factor,chunk.pos[1]*factor,factor,factor)
        self.blit_rect.move_ip(-self.camera.int_pos.x,-self.camera.int_pos.y)
        display_rect = self.surf.get_rect()
        if replace_bg:
            self.surf.fill(((0,0,0,0)),self.blit_rect)
        if not self.blit_rect.colliderect(display_rect):return False
        #if blit_tiles:
        blit_list  = chunk.get_tile_blit_list(self.camera,tileset,animated_tileset)
        self.surf.blits(blit_list)

        #self.surf.blit(chunk.surf,self.blit_rect)
        #print(rect)

        return True

    def get_visible_chunks(self):
        x =int((WIDTH//2+self.camera.int_pos.x)//(self.chunk_size*64))
        y = int((HEIGHT//2+self.camera.int_pos.y)//(self.chunk_size*64))
        num = [(0,0),(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1),(-1,1),(1,-1),(-2,0),(-2,1),(-2,-1),(2,-1),(2,0),(2,1)]
        group =[]
        for i in num:
            chunk = self.get_chunk(x+i[0],y+i[1])
            if not chunk:continue

            group.append([x+i[0],y+i[1],chunk])
        return group

    def blit_chunks(self,tileset=None,animated_tileset=None,blit_tiles=False):
        counter = 0
        self.surf.fill((0,0,0,0))
        chunk_list =  self.get_visible_chunks()
        for chunk_value in chunk_list:
            counter +=self.blit_chunk(*chunk_value[2].pos,blit_tiles,False,tileset,animated_tileset)
        #print("Blit chunks")
        return counter


    def reload(self,tileset,animated_tileset):
        self.tileset = tileset
        self.animated_tileset=animated_tileset
        self.blit_chunks(self.tileset,self.animated_tileset,True)
    def update(self,dt):
        chunk_list =  self.get_visible_chunks()
        #if chunk_list : print("-->",chunk_list)
        for chunk_value in chunk_list:
            chunk_value[2].update(dt)
