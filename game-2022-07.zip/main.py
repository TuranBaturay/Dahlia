
from level import Level
from tile import Tile
from player import Player
from panel import Panel
from toggle import Toggle
from text_input import TextInput
from button import Button
from textbox import TextBox
from slider import Slider
from debugger import Debugger
from particle_manager import ParticleManager
from camera import Camera
import lib as lib
import pygame
from pygame.locals import *
from pygame import Vector2
from random import randint,random
from math import cos,floor,sin
import os
pygame.mixer.pre_init()
pygame.init()
monitor_info = pygame.display.Info()
MONITOR_WIDTH = monitor_info.current_w
MONITOR_HEIGHT = monitor_info.current_h

pygame.mixer.init(channels=4)

FPS =60
FLAGS = 0#BLEND_ALPHA_SDL2


_screen = pygame.display.set_mode((lib.WIDTH,lib.HEIGHT),depth = 32) #main screen - display is blitted on this
_display = pygame.surface.Surface((lib.WIDTH,lib.HEIGHT))#,SRCALPHA) # game screen - everything is blitted on here
_clock = pygame.time.Clock()

################################################################################################



class Game:
    def __init__(self,_display) -> None:
        #Load ressources
        self.musics = {}
        music_path = "Audio/Music/"
        for file in os.listdir(music_path):
            f = os.path.join(music_path, file)
            if os.path.isfile(f) and file[-4:] == '.mp3':
                self.musics[file[:-4]]=pygame.mixer.Sound(f)






        #Rendering
        self.bg = pygame.image.load("Assets/images/sky.png").convert()
        self.bg_scaled = pygame.surface.Surface((2160,1200),HWACCEL)
        pygame.transform.scale(self.bg,(2160,1200),self.bg_scaled)
        self.effect_surf = pygame.surface.Surface((lib.WIDTH,lib.HEIGHT))
        self.effect_surf.set_colorkey((255,255,255))
        self.dummy_surf = pygame.surface.Surface((64,64))

        self.ratio = [1,1]
        self.x_offset = 0
        self.show_hitbox = False
        self.screen_shake = [0,0,0,False]

        self.tileset_list = []
        self.load_ressources()

        #Class instances

        self.camera = Camera(self)
        self.debugger = Debugger(_display)
        self.player = Player(_display,self)
        self.level = Level(_display,self)

        #Class setup
        self.debugger.toggle_visibility()
        self.player.go_to([16*64,16*64],anchor = 's')
        self.camera.set_target(self.player.rect.center)


        #Load level
        #self.level.load_all()
        self.level.load_from_file('level')
        print("-"*30)

        #Game Logic

        self.previous_mode = 'game'
        self.mode = "game"
        self.edit_info = {
        'alpha_surf':pygame.surface.Surface((64,64),SRCALPHA),
        'page':[0 for _ in self.tileset_list],
        'selected_tile_index':[0 for _ in self.tileset_list],
        'mouse_flag':False,
        'tile':Tile((0,0)),
        'onion_skin':False,
        'layer':0,
        'tileset_index':0}
        self.max_layers = 5
        #print(len(self.tileset_list))
        self.edit_info['alpha_surf'].set_alpha(128)


        #Setup parameters


        self.edit_gui = []
        self.init_gui()
        self.set_layer(0)

        self.vignette_close = 0
        self.vignette_open = lib.WIDTH
        self.vignette_func = None

        self.bgm_channel = pygame.mixer.Channel(1)
        pygame.mixer.set_reserved(1)
        #self.toggle_music.toggle(False)
        self.virtual_mouse = [0,0]
        self.track = 0
        self.set_track('theme')
        self.toggle_music.toggle(False)
        self.go_to_page(0)
        self.set_cursor_index(0)

    ################################################################################################
    def vignette_set_func(self,func):
        if self.vignette_close != 0 or self.vignette_open < lib.WIDTH:return
        print("Vignette set HERE")
        self.vignette_func = func
        self.vignette_close = lib.WIDTH

    def load_ressources(self):
        self.tileset = lib.load_tileset("Assets/Tiles/tileset.png",(64,64))
        self.animated_tileset = lib.load_animated_tileset("Assets/Tiles/animated_tileset.png",(64,64))
        self.tileset_list = []
        self.tileset_list = [self.tileset,self.animated_tileset]
    def load(self,filename):
        if not filename: return False
        #print("HERE 1")
        if not self.level.level_exists(filename):return False
        print("HERE 2")
        self.vignette_set_func(func = lambda : [self.level.load_from_file(filename),self.level.load_all(),self.set_layer(),self.set_layer_gui()])
        #self.set_layer(0)

    def save(self,path):
        if not path:return
        self.level.save_to_file(path)


    def init_gui(self):
        ypos = lib.HEIGHT-200
        self.menu_bar = Panel(self.edit_gui,0,ypos,lib.WIDTH,200,color=lib.dark_blue)
        self.tile_selection_panel = Panel(None,0,ypos,4*(80)+10,200,[0,0,0])
        self.tileset_name = TextBox(self.edit_gui,*self.tile_selection_panel.rect.topleft ,self.tile_selection_panel.rect.w,30,text = 'tileset',color=lib.wet_blue)
        self.tileset_prev = Button(self.edit_gui,*self.tileset_name.rect.topleft,30,30,text='<',func=lambda : self.change_tileset(-1),color=lib.wet_blue)
        self.tileset_next = Button(self.edit_gui,self.tileset_name.rect.right-30,self.tileset_name.rect.y,30,30,text='>',func=lambda : self.change_tileset(1),color=lib.wet_blue)

        self.tile_button_list = []
        for y in [0,80]:
            print(y)
            for i in range(4):
                Button(self.tile_button_list,self.tile_selection_panel.rect.x+(10+i*70),self.tileset_name.rect.bottom+10+y,64,64)


        self.page_num_panel = Panel(None,self.tile_selection_panel.rect.right-30,self.menu_bar.rect.y+60,30,110,[0,0,0,0])
        self.page_down =Button(self.edit_gui,*self.page_num_panel.rect.topleft ,30,30,"-",func= lambda :self.go_to_page(self.edit_info['page'][self.edit_info['tileset_index']]-1),color=lib.wet_blue)
        self.page_num = TextBox(self.edit_gui,self.page_num_panel.rect.x,self.page_num_panel.rect.y+40 ,30,30,text = str(self.edit_info['page'][self.edit_info['tileset_index']]+1),color=lib.wet_blue)
        self.page_up =  Button(self.edit_gui,self.page_num_panel.rect.x,self.page_num_panel.rect.bottom-30 ,30,30,"+",func= lambda :self.go_to_page(self.edit_info['page'][self.edit_info['tileset_index']]+1),color=lib.wet_blue)


        settings = Panel(None,lib.WIDTH-420,self.menu_bar.rect.top,200,self.menu_bar.rect.h)
        TextBox(self.edit_gui,*settings.rect.topleft,settings.rect.w,30,text='Settings',color=lib.wet_blue)
        self.toggle_collision = Toggle(self.edit_gui,settings.rect.x,settings.rect.y+30,200,40,"Collisions",color=lib.wet_blue)
        self.toggle_music = Toggle(self.edit_gui,settings.rect.x,settings.rect.y+70,160,40,"Music",func=lambda x : self.volume_slider.set_value(x),color=lib.wet_blue)
        self.next_track = Button(self.edit_gui,settings.rect.x+180,settings.rect.y+70,20,40,text='>',func=self.next_track,color=lib.wet_blue)
        self.prev_track = Button(self.edit_gui,settings.rect.x+160,settings.rect.y+70,20,40,text='<',func=self.prev_track,color=lib.wet_blue)
        self.volume_slider =Slider(self.edit_gui,settings.rect.x,settings.rect.y+110,200,40,"Volume",self.music_set_volume,color=lib.wet_blue)

        self.load_button = Button(self.edit_gui,settings.rect.centerx-70,settings.rect.y+160,60,30,text='Load',func=lambda : self.text_input.ask_input(func = self.load,label="Load level :"),color=lib.wet_blue)
        self.save_button = Button(self.edit_gui,settings.rect.centerx+10,settings.rect.y+160,60,30,text='Save',func=lambda : self.text_input.ask_input(func = self.save,label="Save level as ?"),color=lib.wet_blue)

        self.text_input = TextInput(self.edit_gui,350,40,20,20)
        self.text_input.hide()
        self.layer_buttons = []
        self.layer_panel =  Panel(self.edit_gui,lib.WIDTH-200,self.menu_bar.rect.top,200,self.menu_bar.rect.h,color=lib.dark_blue)
        TextBox(self.edit_gui,*self.layer_panel.rect.topleft,self.layer_panel.rect.w,30,text = "Layers",color=lib.wet_blue)
        self.layer_add_button = Button(self.edit_gui,self.layer_panel.rect.right-30,self.layer_panel.rect.y,30,30,text='+',func=lambda :self.text_input.ask_input(func = self.add_layer,label="Layer name :"),color=lib.wet_blue)
        self.set_layer_gui()

    def change_tileset(self,index,absolute=False):
        if not absolute:
            index =  self.edit_info['tileset_index']+index
        if index >= len(self.tileset_list):index = 0
        if index <0 : index = len(self.tileset_list)-1
        self.edit_info['tileset_index']=index
        self.go_to_page(None)
        if index == 0:self.tileset_name.set_text("tileset")
        elif index ==1:self.tileset_name.set_text("animated tileset")

    def add_layer(self,text):
        if text==None:return
        if text in self.level.get_layer_list():return


        self.level.add_layer(text)
        self.set_layer_gui()
        if len(self.level.layers) >= self.max_layers :
            self.layer_add_button.disable()
            print("MAX LAYER SIZE")
            return
        #self.set_layer(text)

    def remove_layer(self,layer):
        if not layer in self.level.get_layer_list():return
        if not self.level.remove_layer(layer):return
        self.set_layer_gui()
        if layer == self.edit_info['layer']:
            self.set_layer(-1)
        print("REMOVED")
        self.layer_add_button.enable()

    def rename_layer(self,oldname,new_name):
        print(oldname,new_name)
        if oldname == None or new_name == None:return
        if not self.level.rename_layer(oldname,new_name):return
        self.set_layer_gui()
        print("RENAMED")

    def swap_layers(self,index1,index2):
        if not self.level.swap_layers(index1,index2):return
        self.set_layer(None)
        self.set_layer_gui()

    def set_layer(self,layer_name=0):
        if layer_name == None:
            layer_name = self.edit_info['layer']
        if isinstance(layer_name,int):
            index = layer_name
            if index ==-1:index = len(self.level.layers)-1
            layer = self.level.get_layer(index)
            layer_name = self.level.get_layer_name(index)
        else:
            layer = self.level.get_layer(layer_name)
            index = self.level.get_layer_index(layer_name)
        for other in self.level.layers:
            if not (self.mode == 'edit' and  self.edit_info['onion_skin']) or layer_name == other[0]:
                self.level.set_layer_visible(other[0],True)
            else:
                self.level.set_layer_visible(other[0],False)


        #if layer_name == self.edit_info['layer']:return
        self.edit_info['layer']=layer_name
        #self.layer_num.set_text("Layer : "+layer_name)
        for id, buttons in enumerate(self.layer_buttons):
            if id == index:
                buttons[0].set_color(lib.dark_green)
            else:
                buttons[0].set_color(lib.darker_gray)

    def set_layer_gui(self):
        print("SET LAYER GUI")
        current_length = len(self.layer_buttons)
        new_length = len(self.level.layers)
        delta = new_length-current_length
        if delta != 0:
            if delta > 0 : # ADD LAYER_BUTTON
                for i in range(delta):
                    y_pos = (current_length+i)*30
                    self.layer_buttons.append([])
                    self.layer_buttons[current_length+i].append(
                        Button(self.edit_gui,self.layer_panel.rect.x,self.layer_add_button.rect.bottom+y_pos,110,30,text='Layer',color = lib.wet_blue))#0
                    self.layer_buttons[current_length+i].append(Button(self.edit_gui,self.layer_panel.rect.x+110,self.layer_add_button.rect.bottom+y_pos,30,30,text='^',color=lib.wet_blue))#1
                    self.layer_buttons[current_length+i].append(Button(self.edit_gui,self.layer_panel.rect.x+140,self.layer_add_button.rect.bottom+y_pos,30,30,text='v',color=lib.wet_blue))#2
                    self.layer_buttons[current_length+i].append(Button(self.edit_gui,self.layer_panel.rect.x+170,self.layer_add_button.rect.bottom+y_pos,30,30,text='x',color=lib.darker_red))#3

            else: # REMOVE LAYER_BUTTON
                for i in range(abs(delta)):
                    buttons = self.layer_buttons.pop()
                    for button in buttons:
                        self.edit_gui.remove(button)


        for i,layer in enumerate(self.level.layers):
            for j in range(1,4) : self.layer_buttons[i][j].enable()
            print(i,layer[0])
            self.layer_buttons[i][0].set_text(layer[0])
            self.layer_buttons[i][0].set_func(lambda layer=layer: self.set_layer(layer[0]))
            self.layer_buttons[i][0].set_right_click_func(lambda layer=layer: self.text_input.ask_input(max_len=15,label="New name",func=lambda new_name: self.rename_layer(layer[0],new_name)))
            self.layer_buttons[i][1].set_func(lambda i=i: self.swap_layers(i,i-1))
            self.layer_buttons[i][2].set_func(lambda i=i: self.swap_layers(i,i+1))
            self.layer_buttons[i][3].set_func(lambda layer=layer: self.remove_layer(layer[0]))


            if i == 0: self.layer_buttons[i][1].disable()
            if i == len(self.level.layers)-1: self.layer_buttons[i][2].disable()


        if len(self.level.layers)==1:
            for i in range(1,4) : self.layer_buttons[0][i].disable()

    def set_track(self,track):
        if not self.bgm_channel.get_busy():
            self.toggle_music.toggle(True)
        key_list = list(self.musics.keys())

        if type(track) is int:
            if (track < 0 or track >=len(self.musics)):
                return
            self.track = track
            track = key_list[track]
        else:
            if not track in self.musics.keys():
                return
            self.track = key_list.index(track)
            #print(self.track)

        if self.bgm_channel.get_sound() != self.musics[track]:
            self.bgm_channel.play(self.musics[track],loops=-1)

    def next_track(self):
        self.track+=1
        if self.track >= len(self.musics):
            self.track = 0
        self.set_track(self.track)

    def prev_track(self):
        self.track-=1
        if self.track < 0:
            self.track = len(self.musics)-1
        self.set_track(self.track)

    def music_set_volume(self,float):
        self.bgm_channel.set_volume(float)
        if float>0:
            if not self.toggle_music.get(): self.toggle_music.toggle(True,callback=False)
        else:
            if self.toggle_music.value : self.toggle_music.toggle(False,callback=False)

    def go_to_page(self,page=0):
        tileset = self.get_current_tileset()
        if not tileset : return
        #if  self.edit_info['tileset_index']==0:return
        if page == None:page = self.edit_info['page'][self.edit_info['tileset_index']]

        self.page_down.disable() if page <= 0 else self.page_down.enable()
        self.page_up.disable() if page*8+8 >= len(tileset) else self.page_up.enable()

        self.edit_info['page'][self.edit_info['tileset_index']]=page
        self.page_num.set_text(str(self.edit_info['page'][self.edit_info['tileset_index']]+1))
        for i,button in enumerate(self.tile_button_list):
            index = self.edit_info['page'][self.edit_info['tileset_index']]*8+i
            if self.edit_info['tileset_index']==0:
                if index >=len(self.tileset_list[0]):
                    button.hide()
                    continue
                button.set_img(tileset[index])
                button.set_func(func = lambda index=index : self.set_cursor_data({'index':index}))
                button.show()
            else:
                if index >= len(self.tileset_list[1]):
                    button.hide()
                    continue
                button.set_img(tileset[index][0])
                button.show()

                duration = [20]*(len(tileset[index]))
                button.set_func(func = lambda index=index,duration=duration: self.set_cursor_data({'index':index,'animation_duration':duration}))

    def get_current_tileset(self):
        return self.tileset_list[self.edit_info['tileset_index']]

    def get_mouse_pos(self):
        pos = Vector2(pygame.mouse.get_pos())
        pos.x -= self.x_offset
        pos.x = pos.x // self.ratio[0]
        pos.y = pos.y // self.ratio[1]
        return pos

    def cache_surface(self,scale):
        if not str(scale) in self.cached_surfaces.keys():
            self.cached_surfaces[str(scale)] = pygame.surface.Surface((scale))
        return self.cached_surfaces[str(scale)]

    def update_cursor(self):
        tileset = self.get_current_tileset()
        img = tileset[self.edit_info['tile'].index]
        self.edit_info['selected_tile_index'][self.edit_info['tileset_index']]=self.edit_info['tile'].index

        if isinstance(img,list):img = img[0]
        if self.edit_info['tile'].flip : img = pygame.transform.flip(img,True,False)
        self.edit_info['alpha_surf'].fill((0,0,0,0))
        self.edit_info['alpha_surf'].blit(img,(0,0))

    def set_cursor_index(self,index):
        self.edit_info['tile'].index = index
        self.update_cursor()

    def set_cursor_data(self,data):
        self.edit_info['tile'].set(data)

        self.update_cursor()

    def edit_loop(self,dt,mouse,mouse_button,mouse_pressed):

        if not mouse_pressed[0] and self.edit_info['mouse_flag']:
            self.edit_info['mouse_flag']=False
        if mouse_button[1] and not self.edit_info['mouse_flag'] :
            self.edit_info['mouse_flag']=True


        hovered_tile = self.level.get(*self.virtual_mouse,self.edit_info['layer'])


        source = self.edit_info['tile']
        source.rect.topleft = [i*64 for i in self.virtual_mouse]
        source.collision=self.toggle_collision.get()

        for panel in self.edit_gui :
            #if  mouse.y >= self.menu_bar.rect.y:

            if panel.visible :
                panel.update(mouse,mouse_button,mouse_pressed)
                _display.blit(panel.image,panel.rect)



        for i,button in enumerate(self.tile_button_list):
            #button.set_text(str(i)
            index = self.edit_info['page'][self.edit_info['tileset_index']]*8+i
            if button.visible:
                button.update(mouse,mouse_button,mouse_pressed)
                if self.edit_info['selected_tile_index'][self.edit_info['tileset_index']] == index:
                    _display.blit(button.image,button.rect.move(0,4*cos(pygame.time.get_ticks()*(1/150))))
                    pygame.draw.rect(_display,lib.dark_green,button.rect.move(0,4*cos(pygame.time.get_ticks()*(1/150))),3)
                else:
                    _display.blit(button.image,button.rect)
                    if button.mouse_in:
                        pygame.draw.rect(_display,(180,180,180),button.rect,2)



        if mouse_button[2]:
            source.flip = not source.flip
            self.update_cursor()


        if  mouse.y >= self.menu_bar.rect.y:
            return
        cursor = pygame.Rect(mouse.x+self.camera.int_pos.x,mouse.y+self.camera.int_pos.y,64,64)
        if self.edit_info['mouse_flag']:
            if not (isinstance(hovered_tile,Tile) and  hovered_tile.format() ==source.format()):

                self.level.set(*self.virtual_mouse,self.edit_info['layer'],source.format())
                #print(self.edit_info['tile'].format())
        elif mouse_pressed[2] and hovered_tile!=None:
            #print("remove",virtual_mouse,virtual_mouse)
            self.level.remove(*self.virtual_mouse,self.edit_info['layer'])

        _display.blit(self.edit_info['alpha_surf'],mouse+(-32,-32))
        pygame.draw.rect(_display,(200,200,200),(*mouse+(-32,-32),64,64),3)

    def keyboard_mouse_input(self,keys,mouse_pressed):

        if not self.debugger.show:
            if keys[K_h]:
                self.show_hitbox = True
            else:
                self.show_hitbox = False
        if self.mode=="edit":
            self.camera.true_pos += Vector2(10*(keys[K_RIGHT]-keys[K_LEFT] ),10*(keys[K_DOWN]-keys[K_UP] ))

    def on_key_down(self,key,caps=None):
        if self.mode == 'text_input':
            self.text_input.key_down(key,caps)
            return

        elif key == K_o and self.mode=="edit":
            self.edit_info['onion_skin']=not self.edit_info['onion_skin']
            self.set_layer(None)
        elif key == K_e:
            if self.mode == "game":
                self.mode = "edit"
            elif self.mode=="edit":
                self.mode="game"
        elif key == K_f:
            pygame.display.toggle_fullscreen()
        elif key == K_q :
            self.player.go_to([i*64 for i in self.virtual_mouse])
        elif key == K_s :
            self.save_button.click()
        elif key == K_l:
            self.load_button.click()
        elif key == K_m:
            print([len(i) for i in self.animated_tileset])
        elif key == K_b:
            self.vignette_close = lib.WIDTH//2
        elif key == K_k:
            if not self.screen_shake[3]:
                self.screen_shake[3]=True
                self.screen_shake[2]=0.1
        elif key == K_d:
            self.debugger.toggle_visibility()
            self.show_hitbox = self.debugger.show
        elif key == K_r:
            self.load_ressources()
            self.level.load_all(self.tileset,self.animated_tileset)
            self.update_cursor()
        elif key == K_p:
            copy_tile = self.level.get(*self.virtual_mouse[:2],self.edit_info['layer'])
            if copy_tile!=None:
                self.set_cursor_data(copy_tile.format())
                if copy_tile.animated:
                    self.change_tileset(1,True)
                else:
                    self.change_tileset(0,True)
                print(self.edit_info['tile'].format())

    def screen_shake_update(self):
        c = self.screen_shake[2]
        self.screen_shake[0]=cos(0.05*c)*cos(1.5*c)*40
        self.screen_shake[1]=cos(0.05*c)*cos(1.5*c)*40

        self.screen_shake[2]+=1

        self.camera.true_pos.x += self.screen_shake[0]
        self.camera.true_pos.y += self.screen_shake[1]

    def main(self,_display,_screen,_clock):

        #size = [_screen.get_width(),_screen.get_height()]
        loop = True
        change_scale = True
        mouse_button = {1:False,2:False,3:False,4:False,5:False}
        caps = False

        while loop:

            dt = _clock.tick(FPS)
            dt/=1000
            #_display.fill((0,0,0,0))
            _display.fill((32, 65, 64))

            if self.screen_shake[2]>30:self.screen_shake = [0,0,0,False]
            if self.screen_shake[3]: self.screen_shake_update()

            mouse_button = {1:False,2:False,3:False,4:False,5:False}
            keys = pygame.key.get_pressed()


            for event in pygame.event.get():
                #print(pygame.event.event_name(event.type))
                if event.type == QUIT:
                    loop = False
                if event.type == MOUSEBUTTONDOWN and event.button in mouse_button.keys():
                    mouse_button[event.button] = True
                if event.type == lib.INPUTBOX:
                    if event.key=='ON':
                        self.previous_mode = self.mode
                        self.mode = 'text_input'
                        pygame.key.set_repeat(300, 20)
                        #print("ON Event")
                    elif self.mode == 'text_input':
                        #print("Recieved ->",event.text)
                        self.mode = self.previous_mode
                        pygame.key.set_repeat()
                        mouse_button = {1:False,2:False,3:False,4:False,5:False}
                        self.edit_info['mouse_flag']=False
                        #mouse_pressed = (False,False,False)
                        #print("Now")
                if event.type == KEYDOWN:
                    if event.mod & pygame.KMOD_SHIFT or event.mod & pygame.KMOD_CAPS:
                        caps = True
                    else:
                        caps= False
                    self.on_key_down(event.key,caps)


            if not pygame.key.get_focused():
                pygame.time.wait(100)
                _clock.tick(FPS)
                continue

            mouse = self.get_mouse_pos()
            mouse_pressed = pygame.mouse.get_pressed()

            self.virtual_mouse = [floor((mouse.x+ self.camera.int_pos.x)/64 ),floor((mouse.y+self.camera.int_pos.y)/64)]

            self.debugger.set("FPS",int(_clock.get_fps()),True)
            self.debugger.set("Render time  in sec",dt,True)
            self.debugger.set("Resolution",(lib.WIDTH,lib.HEIGHT))
            self.debugger.set("Player",str(self.player.rect.center))
            self.debugger.set("Player tile",str(self.player.player_tile))
            self.debugger.set("Player State",self.player.state)
            self.debugger.set("Camera ",self.camera.int_pos)
            self.debugger.set("Mouse",mouse_button)
            self.debugger.set("Tiles ",f"total : {self.level.total}")
            self.debugger.set("Source",self.edit_info['tile'].format())
            self.debugger.set("In-game mouse",self.virtual_mouse)
            self.debugger.set("selected_layer",self.edit_info['layer'])
            info = [layer[1].total for layer in self.level.layers]
            self.debugger.set("Layer totals",info)
            self.debugger.set("info",len(self.level.layers))



            #_display.blit(self.bg_scaled,(0,0),(lib.WIDTH//2+self.camera.int_pos.x/10,200+self.camera.int_pos.y/10,lib.WIDTH,lib.HEIGHT))

            if self.debugger.show:
                hovered_tile = self.level.get(*self.virtual_mouse,self.edit_info['layer'])

                text = None
                if hovered_tile:
                    text = hovered_tile.format()
                self.debugger.set("Tile",text)

            if self.mode == 'game' or self.mode=='edit':
                self.keyboard_mouse_input(keys,mouse_pressed)
                self.level.update(dt)
                res = self.level.blit_layers(hitbox = self.show_hitbox)
                self.debugger.set("CPH ",res)
                if self.mode=="game":
                    #self.player.draw()
                    self.player.update(dt)

                elif self.mode=="edit":
                    self.player.draw()

                 # ------------------------------------EDIT MODE
                if self.mode=="edit":
                    self.edit_loop(dt,mouse,mouse_button,mouse_pressed)
                    #pygame.time.wait(2)

                self.debugger.update()
                self.camera.set_target(Vector2(self.player.rect.centerx,self.player.rect.y-lib.HEIGHT/16))
                self.camera.update(dt)

            if self.mode == 'text_input':
                self.text_input.update(mouse,mouse_button,pygame.mouse.get_pressed())
                _display.blit(self.text_input.image,self.text_input.rect)
                pygame.time.wait(30)



            _screen.blit(_display,(0,0))
            if self.vignette_open<lib.WIDTH:
                #print(self.vignette_open)

                self.vignette_open = self.vignette_open  +1 +  abs(self.vignette_open*(1/15))
                if  self.vignette_open>2:
                    #print(self.vignette_open)
                    pygame.draw.circle(self.effect_surf,(255,255,255),(self.player.draw_rect.center),self.vignette_open)

                _screen.blit(self.effect_surf,(0,0))
            elif self.vignette_close:
                self.effect_surf.fill((0,0,0))

                pygame.draw.circle(self.effect_surf,(255,255,255),(self.player.draw_rect.center),self.vignette_close)
                self.vignette_close = int(self.vignette_close -1 - self.vignette_close/15 )
                if self.vignette_close <=1:
                    self.vignette_close = 0
                    self.effect_surf.fill((0,0,0))
                    if self.vignette_func :
                        #print("HERE func")
                        self.vignette_func()
                        self.vignette_func = None
                    self.vignette_open = -200
                #mask = pygame.mask.from_surface(self.effect_surf)
                _screen.blit(self.effect_surf,(0,0))
            pygame.display.flip()



if __name__ == '__main__':
    game  = Game(_display)
    game.main(_display,_screen,_clock)
