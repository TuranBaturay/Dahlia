import pygame
import lib as lib
class Panel(pygame.sprite.Sprite):
    def __init__(self,list=None,x=0,y=0,width=100,height=100,color=None,border=0):
        pygame.sprite.Sprite.__init__(self)

        if list!= None : list.append(self)
        self.image = pygame.surface.Surface((width,height),pygame.SRCALPHA)
        self.rect = pygame.rect.Rect(x,y,width,height)
        self.mouse_in = False
        self.mouse_pressed = [False,False,False]
        self.mouse_in_flag = False
        self.visible = True
        border_color = (100,100,100)
        if not color:
            color = (0,0,0)
        self.image.fill(color)

        if not color and border:
            border_color = color
        if border:
            #print(border_color)
            #self.image.fill((255,0,255))
            pygame.draw.rect(self.image,border_color,(0,0,width,height),border)
            #self.image.set_colorkey((255,0,255))
            #if len(color)>3: self.image.set_alpha(color[3])

    def mouse_enter(self):
        pass
    def mouse_leave(self):
        pass
    def show(self):
        self.visible = True
    def hide(self):
        self.visible = False
    def update(self,mouse_pos,mouse_button,mouse_pressed=None):
        if self.rect.collidepoint(mouse_pos):
            self.mouse_in = True
            if not self.mouse_in_flag :
                self.mouse_in_flag = True
                self.mouse_pressed = mouse_pressed

                self.mouse_enter()
        else:
            self.mouse_in= False
            if self.mouse_in_flag:
                self.mouse_in_flag = False

                self.mouse_leave()
