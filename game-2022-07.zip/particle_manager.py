from math import cos, sin
from random import randint,random
import pygame
from lib import *
from pygame.math import Vector2
from pygame.locals import *
class ParticleManager():
    def __init__(self,_display,camera) -> None:
        self.particles = []
        self.max = 500
        self.display = _display
        self.items = 0
        self.cache = {}
        self.gravity = .1
        self.friction = 0.9
        self.camera = camera
        self.surf = self.display
        #self.surf = pygame.surface.Surface((WIDTH,HEIGHT)).convert_alpha()
        self.sfx = {'fire':pygame.mixer.Sound('Audio/sfx/fire.wav')}

        self.channel = pygame.mixer.Channel(0)
        pygame.mixer.set_reserved(0)
        self.channel.set_volume(0)
        #               high in left       high in right
        self.x = 0
        self.stop = False
        self.volume = [0,0]
        self.target_volume = [0,0]
        self.particle_rect = pygame.rect.Rect(0,0,0,0)
    def add_particle(self,x,y,n=1,xvel_range=None,yvel_range = None,life=200):
        #vel = Vector2(0,0)
        self.stop = False
        size = int(30+30*min(self.items/200,1))
        life = life
        color = [60,20,10]
        x_range = xvel_range if xvel_range else (-5,5)
        y_range = yvel_range if yvel_range else (-5,0)
        x_range = [int(i*(1+min(self.items/200,1))) for i in x_range]
        y_range = [int(i*(1+min(self.items/200,1))) for i in y_range]

        vel = [randint(*x_range),randint(*y_range)]
        uniq = random()
        if len(self.particles) > self.max:
            self.particles[0]= [[x,y],vel,size,life,color,uniq]
        else:
            self.particles.append([[x,y],vel,size,life,color,uniq])
            self.items += 1
        if n > 1:
            self.add_particle(x,y,n-1,xvel_range,yvel_range,life)
        if x > 0 and x<WIDTH:
            self.x = x
    def remove_particle(self,index):
        #print("Pop --->",self.particles.pop(index))
        self.particles.pop(index)
        self.items -=1
    def update(self):
        if self.stop:return
        if not self.channel.get_busy():

            self.channel.play(self.sfx['fire'])
        #print(self.x)
        self.factor = [round(cos((1.5/(WIDTH))*(0-self.x)),2),round(cos((1.5/(WIDTH))*(WIDTH-self.x)),2)]
        percentage = min(5*self.items/self.max,1)
        #percentage = round(percentage,2)
        #self.factor = [round(i,2) for i in self.factor]
        self.target_volume = percentage*self.factor[0],percentage *self.factor[1]
        #print(self.volume,self.target_volume)
        self.volume = [round(self.volume[i]+(self.target_volume[i]-self.volume[i])/5,3) for i in [0,1]]
        self.volume = [0 if self.volume[i]<=0.002 and self.target_volume[i]<self.volume[i] else self.volume[i] for i in [0,1] ]
        self.channel.set_volume(*self.volume)

        if self.volume == [0.0,0.0]:
            self.stop = True
            #print("stop")
        if not self.items:
            return
        for index in range(self.items):
            particle = self.particles[self.items-index-1]
            if not particle[2] in self.cache.keys():
                print(particle[2])
                surf =pygame.Surface((particle[2],particle[2]))
                surf.fill(particle[4])
                #self.particle_rect.update(*[[particle[2]]*2,[particle[2]*2]*2])
                #pygame.draw.rect(surf,particle[4],self.particle_rect)

                self.cache[particle[2]] = surf

            surf = self.cache[particle[2]]
            self.particle_rect.topleft = (particle[0][0]-particle[2]//2,particle[0][1]-particle[2]//2)
            self.particle_rect.normalize()
            self.display.blit(surf,self.particle_rect,special_flags = BLEND_RGB_ADD)
            particle[4] = [min(i+2,255) for i in particle[4]]

            particle[0][0]+=particle[1][0]
            particle[0][1]+=particle[1][1]

            particle[3]-=1
            particle[2]-=1
            if particle[3]<=0 or particle[2] <= 1 :
                self.remove_particle(self.items-index-1)
